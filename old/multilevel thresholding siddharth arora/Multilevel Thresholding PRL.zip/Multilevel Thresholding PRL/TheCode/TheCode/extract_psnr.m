

for i=1:length(dat)./9
    newdata(1:6,i)=dat(6*(i-1)+1:6*i);
end